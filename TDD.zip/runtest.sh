#!/bin/bash

# Update Package Index
sudo apt -y update

#Install PHP
apt install -y php

# Run Command
apt install -y composer

# RUN composer update
composer update

# CHECK ANAGRAM TEST
php index.php 1
# Need to setup curl & apache2 or httpd
# curl http://localhost/Alam/index.php?task=1

# CHECK BFMD TEST
php index.php 2
# Need to setup curl & apache2 or httpd
# curl http://localhost/Alam/index.php?task=2

# CHECK TDD NUMBER FACTORS TEST
php index.php 3
# Need to setup curl & apache2 or httpd
# curl http://localhost/Alam/index.php?task=3

# For All
# php index.php 0
# curl http://localhost/Alam/index.php?task=0